<?php

/*
 * @author     M2E Pro Developers Team
 * @copyright  2011-2015 ESS-UA [M2E Pro]
 * @license    Commercial use is forbidden
 */

class Ess_M2ePro_Block_Adminhtml_Development_Tabs_Module extends Mage_Adminhtml_Block_Widget
{
    //########################################

    public function __construct()
    {
        parent::__construct();

        // Initialization block
        // ---------------------------------------
        $this->setId('developmentModule');
        // ---------------------------------------

        $this->setTemplate('M2ePro/development/tabs/module.phtml');
    }

    //########################################

    protected function _beforeToHtml()
    {
        $this->setChild('development_module_module',
            $this->getLayout()->createBlock(
                'M2ePro/adminhtml_development_tabs_command_group',
                '',
                array('controller_name'=>Ess_M2ePro_Helper_View_Development_Command::CONTROLLER_MODULE_MODULE)
            )
        );

        $this->setChild('development_module_synchronization',
            $this->getLayout()->createBlock(
                'M2ePro/adminhtml_development_tabs_command_group',
                '',
                array('controller_name'=>Ess_M2ePro_Helper_View_Development_Command::CONTROLLER_MODULE_SYNCHRONIZATION)
            )
        );

        $this->setChild('development_module_integration',
            $this->getLayout()->createBlock(
                'M2ePro/adminhtml_development_tabs_command_group',
                '',
                array('controller_name'=>Ess_M2ePro_Helper_View_Development_Command::CONTROLLER_MODULE_INTEGRATION)
            )
        );

        return parent::_beforeToHtml();
    }

    //########################################
}